require('dotenv').config();
const mongoose = require('mongoose');
const ensureDemoUsers = require('./config/seedDemo');

(async () => {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/staffsync');
  await ensureDemoUsers();
  process.exit(0);
})();
