const User = require('../models/User');
const Announcement = require('../models/Announcement');

const DEMO = [
  { name: 'Hina HR', email: 'hr@staffsync.com', password: 'Hr@12345', role: 'hr', department: 'Human Resources', position: 'HR Manager' },
  { name: 'Manish Manager', email: 'manager@staffsync.com', password: 'Manager@123', role: 'manager', department: 'Engineering', position: 'Team Lead' },
  { name: 'Esha Employee', email: 'employee@staffsync.com', password: 'Employee@123', role: 'employee', department: 'Engineering', position: 'Developer' },
  { name: 'Rohan Singh', email: 'rohan@staffsync.com', password: 'Employee@123', role: 'employee', department: 'Engineering', position: 'QA Engineer' },
];

// Creates the demo accounts if missing and always resets their password,
// so demo logins never fail. Other users in the database are left untouched.
module.exports = async function ensureDemoUsers() {
  const saved = {};
  for (const d of DEMO) {
    const u = (await User.findOne({ email: d.email })) || new User({ email: d.email });
    u.name = d.name;
    u.password = d.password;
    u.role = d.role;
    u.department = d.department;
    u.position = d.position;
    await u.save();
    saved[d.email] = u;
  }
  await User.updateMany(
    { email: { $in: ['employee@staffsync.com', 'rohan@staffsync.com'] } },
    { manager: saved['manager@staffsync.com']._id }
  );
  if (!(await Announcement.countDocuments())) {
    await Announcement.create({
      title: 'Welcome to StaffSync',
      message: 'Mark your attendance daily and apply for leaves from the Leaves page.',
      postedBy: saved['hr@staffsync.com']._id,
    });
  }
  console.log('Demo accounts ready: hr@staffsync.com / Hr@12345 | manager@staffsync.com / Manager@123 | employee@staffsync.com / Employee@123');
};
