const router = require('express').Router();
const Attendance = require('../models/Attendance');
const User = require('../models/User');
const { protect, authorize } = require('../middleware/auth');

const today = () =>
  new Date().toLocaleDateString('en-CA', { timeZone: process.env.TZ_NAME || 'Asia/Kolkata' });

router.post('/checkin', protect, async (req, res) => {
  const date = today();
  const existing = await Attendance.findOne({ user: req.user._id, date });
  if (existing && existing.checkIn) return res.status(400).json({ message: 'Already checked in today' });
  const rec = await Attendance.create({ user: req.user._id, date, checkIn: new Date() });
  res.status(201).json(rec);
});

router.post('/checkout', protect, async (req, res) => {
  const rec = await Attendance.findOne({ user: req.user._id, date: today() });
  if (!rec || !rec.checkIn) return res.status(400).json({ message: 'Check in first' });
  if (rec.checkOut) return res.status(400).json({ message: 'Already checked out today' });
  rec.checkOut = new Date();
  await rec.save();
  res.json(rec);
});

router.get('/mine', protect, async (req, res) => {
  res.json(await Attendance.find({ user: req.user._id }).sort('-date').limit(60));
});

router.get('/', protect, authorize('hr', 'manager'), async (req, res) => {
  const filter = {};
  if (req.query.date) filter.date = req.query.date;
  if (req.user.role === 'manager') {
    filter.user = { $in: await User.find({ manager: req.user._id }).distinct('_id') };
  }
  res.json(await Attendance.find(filter).populate('user', 'name department').sort('-date').limit(300));
});

module.exports = router;
