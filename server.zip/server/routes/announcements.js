const router = require('express').Router();
const Announcement = require('../models/Announcement');
const { protect, authorize } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  res.json(await Announcement.find().populate('postedBy', 'name').sort('-createdAt'));
});

router.post('/', protect, authorize('hr'), async (req, res) => {
  const a = await Announcement.create({ title: req.body.title, message: req.body.message, postedBy: req.user._id });
  res.status(201).json(await a.populate('postedBy', 'name'));
});

router.delete('/:id', protect, authorize('hr'), async (req, res) => {
  await Announcement.findByIdAndDelete(req.params.id);
  res.json({ message: 'Announcement deleted' });
});

module.exports = router;
