import { useEffect, useState } from 'react';
import { Title } from '../components/Ui';
import api, { errMsg, fmtDate } from '../api';
import { useAuth } from '../AuthContext';

const blank = { title: '', description: '', startDate: '', endDate: '', assignees: [] };

export default function Training() {
  const { user } = useAuth();
  const canManage = ['hr', 'manager'].includes(user.role);
  const [list, setList] = useState([]);
  const [people, setPeople] = useState([]);
  const [form, setForm] = useState(blank);
  const [msg, setMsg] = useState(null);

  const load = async () => {
    setList((await api.get('/training')).data);
    if (canManage) setPeople((await api.get('/users')).data.filter((p) => p._id !== user._id));
  };
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const toggle = (id) =>
    setForm({ ...form, assignees: form.assignees.includes(id) ? form.assignees.filter((x) => x !== id) : [...form.assignees, id] });

  const create = async (e) => {
    e.preventDefault();
    try { await api.post('/training', form); setForm(blank); setMsg(null); load(); }
    catch (err) { setMsg(errMsg(err)); }
  };
  const remove = async (id) => {
    try { await api.delete(`/training/${id}`); load(); } catch (err) { setMsg(errMsg(err)); }
  };

  return (
    <>
      <Title className="mb-3" icon="mortarboard" title="Training" subtitle="Programs to learn and grow" />
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      {canManage && (
        <form className="card card-body mb-3" onSubmit={create}>
          <div className="row g-2">
            <div className="col-md-6"><input className="form-control" placeholder="Program title" value={form.title} onChange={set('title')} required /></div>
            <div className="col-md-3"><input type="date" className="form-control" value={form.startDate} onChange={set('startDate')} required /></div>
            <div className="col-md-3"><input type="date" className="form-control" value={form.endDate} onChange={set('endDate')} required /></div>
            <div className="col-12"><textarea className="form-control" rows="2" placeholder="Description" value={form.description} onChange={set('description')} /></div>
            <div className="col-12">
              <small className="text-muted d-block mb-1">Assign to:</small>
              {people.map((p) => (
                <div className="form-check form-check-inline" key={p._id}>
                  <input className="form-check-input" type="checkbox" id={p._id} checked={form.assignees.includes(p._id)} onChange={() => toggle(p._id)} />
                  <label className="form-check-label" htmlFor={p._id}>{p.name}</label>
                </div>
              ))}
              {!people.length && <small className="text-muted">No team members available.</small>}
            </div>
            <div className="col-12"><button className="btn btn-primary">Create Program</button></div>
          </div>
        </form>
      )}
      <div className="row g-3">
        {list.map((t) => (
          <div className="col-md-6" key={t._id}>
            <div className="card h-100">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <h6>{t.title}</h6>
                  {canManage && (user.role === 'hr' || t.createdBy?._id === user._id) && (
                    <button className="btn btn-sm btn-outline-danger" onClick={() => remove(t._id)}>Delete</button>
                  )}
                </div>
                <p className="mb-1">{t.description}</p>
                <small className="d-block text-muted">{fmtDate(t.startDate)} - {fmtDate(t.endDate)} | By {t.createdBy?.name}</small>
                <small className="d-block mt-1">Assigned: {t.assignees.map((a) => a.name).join(', ') || '-'}</small>
              </div>
            </div>
          </div>
        ))}
      </div>
      {!list.length && <p className="text-muted">No training programs yet.</p>}
    </>
  );
}
