require('dotenv').config();
process.env.JWT_SECRET = process.env.JWT_SECRET || 'staffsync_dev_secret_change_me';
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const ensureDemoUsers = require('./config/seedDemo');

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || true }));
app.use(express.json());

app.get('/', (req, res) => res.send('StaffSync API running'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/leaves', require('./routes/leaves'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/announcements', require('./routes/announcements'));
app.use('/api/training', require('./routes/training'));

app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 11000) return res.status(400).json({ message: 'Duplicate value (email already exists?)' });
  if (err.name === 'ValidationError') return res.status(400).json({ message: Object.values(err.errors)[0].message });
  res.status(500).json({ message: err.message || 'Server error' });
});

const PORT = process.env.PORT || 5000;
connectDB()
  .then(async () => {
    if (process.env.SEED_DEMO !== 'false') await ensureDemoUsers();
  })
  .then(() => app.listen(PORT, () => console.log(`Server running on port ${PORT}`)))
  .catch((e) => { console.error('DB connection failed:', e.message); process.exit(1); });
