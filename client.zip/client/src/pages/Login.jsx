import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { errMsg } from '../api';

const demos = {
  HR: ['hr@staffsync.com', 'Hr@12345'],
  Manager: ['manager@staffsync.com', 'Manager@123'],
  Employee: ['employee@staffsync.com', 'Employee@123'],
};

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <section className="login-side">
        <div className="brand text-white"><span className="brand-mark"><i className="bi bi-people-fill" /></span>StaffSync</div>
        <div>
          <h2>Attendance, leaves and announcements for your whole team.</h2>
          <ul className="login-points">
            <li><i className="bi bi-clock-history" /> Check in and out with one tap</li>
            <li><i className="bi bi-calendar2-check" /> Apply for leave and see approvals instantly</li>
            <li><i className="bi bi-megaphone" /> Never miss a company announcement</li>
          </ul>
        </div>
        <small className="text-white-50">HR, managers and employees each see what they need.</small>
      </section>

      <section className="login-form-wrap">
        <div className="login-card">
          <h1>Welcome back</h1>
          <p className="text-muted mb-4">Log in to your StaffSync account.</p>
          {error && <div className="alert alert-danger py-2" role="alert"><i className="bi bi-exclamation-circle me-1" />{error}</div>}
          <form onSubmit={submit}>
            <label className="form-label" htmlFor="email">Email</label>
            <input id="email" type="email" className="form-control mb-3" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus />
            <label className="form-label" htmlFor="password">Password</label>
            <input id="password" type="password" className="form-control mb-4" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <button className="btn btn-primary w-100 py-2" disabled={busy}>{busy ? 'Logging in...' : 'Log in'}</button>
          </form>
          <div className="demo-box">
            <small className="text-muted d-block mb-2">Try a demo account:</small>
            {Object.entries(demos).map(([label, [e, p]]) => (
              <button key={label} type="button" className="chip" onClick={() => { setEmail(e); setPassword(p); }}>{label}</button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
