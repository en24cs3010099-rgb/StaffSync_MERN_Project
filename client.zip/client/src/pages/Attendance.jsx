import { useEffect, useState } from 'react';
import { Title } from '../components/Ui';
import api, { errMsg, fmtTime } from '../api';
import { useAuth } from '../AuthContext';

const hours = (r) => (r.checkIn && r.checkOut ? ((new Date(r.checkOut) - new Date(r.checkIn)) / 36e5).toFixed(2) : '-');

export default function Attendance() {
  const { user } = useAuth();
  const canView = ['hr', 'manager'].includes(user.role);
  const [mine, setMine] = useState([]);
  const [all, setAll] = useState([]);
  const [date, setDate] = useState(new Date().toLocaleDateString('en-CA'));
  const [msg, setMsg] = useState(null);

  const loadMine = async () => setMine((await api.get('/attendance/mine')).data);
  const loadAll = async () => canView && setAll((await api.get('/attendance', { params: { date } })).data);
  useEffect(() => { loadMine(); }, []);
  useEffect(() => { loadAll(); }, [date]);

  const act = async (path) => {
    try { await api.post(`/attendance/${path}`); setMsg({ type: 'success', text: path === 'checkin' ? 'Checked in' : 'Checked out' }); loadMine(); loadAll(); }
    catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <Title icon="clock-history" title="Attendance" subtitle="Check in, check out and review your hours" />
        <div>
          <button className="btn btn-success me-2" onClick={() => act('checkin')}>Check In</button>
          <button className="btn btn-danger" onClick={() => act('checkout')}>Check Out</button>
        </div>
      </div>
      {msg && <div className={`alert alert-${msg.type} py-2`}>{msg.text}</div>}

      <h6>My records</h6>
      <div className="table-responsive mb-4">
        <table className="table table-sm">
          <thead className="table-light"><tr><th>Date</th><th>Check in</th><th>Check out</th><th>Hours</th></tr></thead>
          <tbody>
            {mine.map((r) => <tr key={r._id}><td>{r.date}</td><td>{fmtTime(r.checkIn)}</td><td>{fmtTime(r.checkOut)}</td><td>{hours(r)}</td></tr>)}
            {!mine.length && <tr><td colSpan="4" className="text-center text-muted">No records yet</td></tr>}
          </tbody>
        </table>
      </div>

      {canView && (
        <>
          <div className="d-flex align-items-center gap-2 mb-2">
            <h6 className="mb-0">{user.role === 'hr' ? 'All employees' : 'My team'} on</h6>
            <input type="date" className="form-control w-auto" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div className="table-responsive">
            <table className="table table-sm">
              <thead className="table-light"><tr><th>Employee</th><th>Department</th><th>Check in</th><th>Check out</th><th>Hours</th></tr></thead>
              <tbody>
                {all.map((r) => <tr key={r._id}><td>{r.user?.name}</td><td>{r.user?.department}</td><td>{fmtTime(r.checkIn)}</td><td>{fmtTime(r.checkOut)}</td><td>{hours(r)}</td></tr>)}
                {!all.length && <tr><td colSpan="5" className="text-center text-muted">No attendance on this date</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  );
}
