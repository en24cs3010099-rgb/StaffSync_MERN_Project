import { useEffect, useState } from 'react';
import { Title, Avatar } from '../components/Ui';
import api, { errMsg, fmtDate } from '../api';
import { useAuth } from '../AuthContext';

const empty = { name: '', email: '', password: '', role: 'employee', department: '', position: '', phone: '', manager: '' };

export default function Employees() {
  const { user } = useAuth();
  const isHR = user.role === 'hr';
  const [list, setList] = useState([]);
  const [managers, setManagers] = useState([]);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [show, setShow] = useState(false);
  const [msg, setMsg] = useState(null);
  const [search, setSearch] = useState('');

  const load = async () => {
    setList((await api.get('/users')).data);
    if (isHR) setManagers((await api.get('/users/managers')).data);
  };
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editId) await api.put(`/users/${editId}`, form);
      else await api.post('/users', form);
      setMsg({ type: 'success', text: editId ? 'Employee updated' : 'Employee added' });
      setForm(empty); setEditId(null); setShow(false);
      load();
    } catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  const edit = (u) => {
    setForm({ name: u.name, email: u.email, password: '', role: u.role, department: u.department, position: u.position, phone: u.phone, manager: u.manager?._id || '' });
    setEditId(u._id); setShow(true);
  };

  const remove = async (u) => {
    if (!window.confirm(`Delete ${u.name}?`)) return;
    try { await api.delete(`/users/${u._id}`); load(); } catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  const filtered = list.filter((u) => (u.name + u.email + u.department).toLowerCase().includes(search.toLowerCase()));

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <Title icon="people" title={isHR ? 'Employees' : 'My team'} subtitle={isHR ? 'Add, edit and manage everyone in the company' : 'People who report to you'} />
        {isHR && <button className="btn btn-primary" onClick={() => { setForm(empty); setEditId(null); setShow(!show); }}>{show ? 'Close form' : 'Add employee'}</button>}
      </div>
      {msg && <div className={`alert alert-${msg.type} py-2`}>{msg.text}</div>}

      {isHR && show && (
        <form className="card card-body mb-3" onSubmit={save}>
          <div className="row g-2">
            <div className="col-md-4"><input className="form-control" placeholder="Full name" value={form.name} onChange={set('name')} required /></div>
            <div className="col-md-4"><input type="email" className="form-control" placeholder="Email" value={form.email} onChange={set('email')} required /></div>
            <div className="col-md-4"><input type="password" className="form-control" placeholder={editId ? 'New password (optional)' : 'Password'} value={form.password} onChange={set('password')} required={!editId} /></div>
            <div className="col-md-3">
              <select className="form-select" value={form.role} onChange={set('role')}>
                <option value="employee">Employee</option><option value="manager">Manager</option><option value="hr">HR</option>
              </select>
            </div>
            <div className="col-md-3"><input className="form-control" placeholder="Department" value={form.department} onChange={set('department')} /></div>
            <div className="col-md-3"><input className="form-control" placeholder="Position" value={form.position} onChange={set('position')} /></div>
            <div className="col-md-3"><input className="form-control" placeholder="Phone" value={form.phone} onChange={set('phone')} /></div>
            <div className="col-md-4">
              <select className="form-select" value={form.manager} onChange={set('manager')}>
                <option value="">No manager</option>
                {managers.map((m) => <option key={m._id} value={m._id}>Manager: {m.name}</option>)}
              </select>
            </div>
            <div className="col-md-8 text-end"><button className="btn btn-success">{editId ? 'Update' : 'Save'} Employee</button></div>
          </div>
        </form>
      )}

      <input className="form-control mb-3" placeholder="Search by name, email or department" value={search} onChange={(e) => setSearch(e.target.value)} />
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-light">
            <tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Position</th><th>Manager</th><th>Joined</th>{isHR && <th />}</tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u._id}>
                <td><div className="d-flex align-items-center gap-2"><Avatar name={u.name} />{u.name}</div></td><td>{u.email}</td>
                <td><span className="badge bg-secondary text-uppercase">{u.role}</span></td>
                <td>{u.department}</td><td>{u.position}</td><td>{u.manager?.name || '-'}</td><td>{fmtDate(u.joinDate)}</td>
                {isHR && (
                  <td className="text-nowrap">
                    <button className="btn btn-sm btn-outline-primary me-1" onClick={() => edit(u)}>Edit</button>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => remove(u)}>Delete</button>
                  </td>
                )}
              </tr>
            ))}
            {!filtered.length && <tr><td colSpan="8" className="text-center text-muted">No employees found</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
