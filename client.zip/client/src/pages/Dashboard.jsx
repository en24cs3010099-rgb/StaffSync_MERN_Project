import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg, fmtDate, fmtTime, statusColor } from '../api';
import { useAuth } from '../AuthContext';

function useClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}

function Stat({ icon, tone, label, value, to }) {
  return (
    <Link to={to} className="stat">
      <span className={`stat-icon tone-${tone}`}><i className={`bi bi-${icon}`} /></span>
      <span>
        <span className="stat-value">{value}</span>
        <span className="stat-label">{label}</span>
      </span>
    </Link>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const now = useClock();
  const canManage = ['hr', 'manager'].includes(user.role);
  const [d, setD] = useState({ announcements: [], mine: [], myLeaves: [], reviews: [], users: [], training: [] });
  const [msg, setMsg] = useState(null);

  const load = () => {
    const get = (url) => api.get(url).then((r) => r.data).catch(() => []);
    Promise.all([
      get('/announcements'), get('/attendance/mine'), get('/leaves/mine'),
      canManage ? get('/leaves') : [], canManage ? get('/users') : [], get('/training'),
    ]).then(([announcements, mine, myLeaves, reviews, users, training]) =>
      setD({ announcements, mine, myLeaves, reviews, users, training }));
  };
  useEffect(load, [canManage]);

  const act = async (path) => {
    try { await api.post(`/attendance/${path}`); setMsg(null); load(); }
    catch (err) { setMsg(errMsg(err)); }
  };

  const todayKey = now.toLocaleDateString('en-CA');
  const rec = d.mine[0]?.date === todayKey ? d.mine[0] : null;
  const hour = now.getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const pending = d.reviews.filter((l) => l.status === 'pending');

  let status = 'You have not checked in yet today.';
  if (rec?.checkOut) status = `Day complete. In at ${fmtTime(rec.checkIn)}, out at ${fmtTime(rec.checkOut)}.`;
  else if (rec?.checkIn) status = `You checked in at ${fmtTime(rec.checkIn)}.`;

  return (
    <>
      <section className="today">
        <div>
          <p className="today-greet">{greet}, {user.name.split(' ')[0]}</p>
          <div className="today-clock">{now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
          <div className="today-date">{now.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
        </div>
        <div className="today-action">
          <p>{status}</p>
          <div className="d-flex gap-2 flex-wrap">
            <button className="btn btn-saffron" disabled={!!rec?.checkIn} onClick={() => act('checkin')}><i className="bi bi-box-arrow-in-right me-1" />Check in</button>
            <button className="btn btn-outline-light" disabled={!rec?.checkIn || !!rec?.checkOut} onClick={() => act('checkout')}><i className="bi bi-box-arrow-right me-1" />Check out</button>
          </div>
          {msg && <small className="text-warning d-block mt-2">{msg}</small>}
        </div>
      </section>

      <div className="stats">
        {canManage && <Stat icon="people" tone="teal" label={user.role === 'hr' ? 'Employees' : 'Team members'} value={d.users.length} to="/employees" />}
        {canManage && <Stat icon="hourglass-split" tone="amber" label="Leaves to review" value={pending.length} to="/leaves" />}
        <Stat icon="calendar2-check" tone="blue" label="My pending leaves" value={d.myLeaves.filter((l) => l.status === 'pending').length} to="/leaves" />
        <Stat icon="mortarboard" tone="violet" label="Training programs" value={d.training.length} to="/training" />
      </div>

      <div className="row g-3">
        <div className="col-lg-7">
          <div className="card h-100">
            <div className="card-header d-flex justify-content-between align-items-center">
              Latest announcements <Link to="/announcements" className="small fw-semibold">View all</Link>
            </div>
            <ul className="list-group list-group-flush">
              {d.announcements.slice(0, 4).map((a) => (
                <li key={a._id} className="list-group-item">
                  <div className="d-flex justify-content-between"><b>{a.title}</b><small className="text-muted">{fmtDate(a.createdAt)}</small></div>
                  <div className="text-muted">{a.message}</div>
                </li>
              ))}
              {!d.announcements.length && <li className="list-group-item text-muted">Nothing posted yet. HR announcements will show up here.</li>}
            </ul>
          </div>
        </div>
        <div className="col-lg-5">
          <div className="card h-100">
            <div className="card-header d-flex justify-content-between align-items-center">
              {canManage ? 'Waiting for your review' : 'My recent leaves'} <Link to="/leaves" className="small fw-semibold">Open leaves</Link>
            </div>
            <ul className="list-group list-group-flush">
              {(canManage ? pending : d.myLeaves).slice(0, 5).map((l) => (
                <li key={l._id} className="list-group-item d-flex justify-content-between align-items-center">
                  <span>
                    {canManage && <b className="d-block">{l.user?.name}</b>}
                    {!canManage && <b className="d-block">{l.type} leave</b>}
                    <small className="text-muted">{fmtDate(l.fromDate)} to {fmtDate(l.toDate)}</small>
                  </span>
                  <span className={`badge bg-${statusColor[l.status]}`}>{l.status}</span>
                </li>
              ))}
              {!(canManage ? pending : d.myLeaves).length && (
                <li className="list-group-item text-muted">{canManage ? 'No requests waiting. You are all caught up.' : 'No leave requests yet. Apply from the Leaves page.'}</li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}
