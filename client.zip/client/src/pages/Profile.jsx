import { useState } from 'react';
import { Title } from '../components/Ui';
import api, { errMsg, fmtDate } from '../api';
import { useAuth } from '../AuthContext';

export default function Profile() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({ name: user.name, phone: user.phone || '', password: '' });
  const [msg, setMsg] = useState(null);

  const save = async (e) => {
    e.preventDefault();
    try {
      const { data } = await api.put('/users/me/profile', form);
      setUser(data);
      setForm({ ...form, password: '' });
      setMsg({ type: 'success', text: 'Profile updated' });
    } catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  return (
    <div style={{ maxWidth: 520 }}>
      <Title className="mb-3" icon="person-circle" title="My profile" subtitle="Update your details and password" />
      {msg && <div className={`alert alert-${msg.type} py-2`}>{msg.text}</div>}
      <div className="card card-body mb-3">
        <div><b>Email:</b> {user.email}</div>
        <div><b>Role:</b> {user.role}</div>
        <div><b>Department:</b> {user.department || '-'}</div>
        <div><b>Position:</b> {user.position || '-'}</div>
        <div><b>Joined:</b> {fmtDate(user.joinDate)}</div>
      </div>
      <form className="card card-body" onSubmit={save}>
        <label className="form-label">Name</label>
        <input className="form-control mb-2" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <label className="form-label">Phone</label>
        <input className="form-control mb-2" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <label className="form-label">New password (optional)</label>
        <input type="password" className="form-control mb-3" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <button className="btn btn-primary align-self-start">Save changes</button>
      </form>
    </div>
  );
}
