const router = require('express').Router();
const Training = require('../models/Training');
const User = require('../models/User');
const { protect, authorize } = require('../middleware/auth');

router.get('/', protect, async (req, res) => {
  let filter = { assignees: req.user._id };
  if (req.user.role === 'hr') filter = {};
  if (req.user.role === 'manager') filter = { $or: [{ createdBy: req.user._id }, { assignees: req.user._id }] };
  res.json(
    await Training.find(filter).populate('createdBy', 'name').populate('assignees', 'name').sort('-startDate')
  );
});

router.post('/', protect, authorize('hr', 'manager'), async (req, res) => {
  const { title, description, startDate, endDate } = req.body;
  let assignees = req.body.assignees || [];
  if (req.user.role === 'manager') {
    const team = (await User.find({ manager: req.user._id }).distinct('_id')).map(String);
    assignees = assignees.filter((id) => team.includes(String(id)));
  }
  if (new Date(endDate) < new Date(startDate))
    return res.status(400).json({ message: 'End date cannot be before start date' });
  const t = await Training.create({ title, description, startDate, endDate, assignees, createdBy: req.user._id });
  res.status(201).json(await t.populate([{ path: 'createdBy', select: 'name' }, { path: 'assignees', select: 'name' }]));
});

router.delete('/:id', protect, authorize('hr', 'manager'), async (req, res) => {
  const t = await Training.findById(req.params.id);
  if (!t) return res.status(404).json({ message: 'Program not found' });
  if (req.user.role === 'manager' && String(t.createdBy) !== String(req.user._id))
    return res.status(403).json({ message: 'You can only delete your own programs' });
  await t.deleteOne();
  res.json({ message: 'Program deleted' });
});

module.exports = router;
