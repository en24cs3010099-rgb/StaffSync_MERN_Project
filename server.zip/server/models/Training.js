const mongoose = require('mongoose');

module.exports = mongoose.model('Training', new mongoose.Schema({
  title: { type: String, required: [true, 'Title is required'] },
  description: { type: String, default: '' },
  startDate: { type: Date, required: [true, 'Start date is required'] },
  endDate: { type: Date, required: [true, 'End date is required'] },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
}, { timestamps: true }));
