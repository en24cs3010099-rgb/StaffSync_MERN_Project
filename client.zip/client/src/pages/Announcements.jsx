import { useEffect, useState } from 'react';
import { Title } from '../components/Ui';
import api, { errMsg, fmtDate } from '../api';
import { useAuth } from '../AuthContext';

export default function Announcements() {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title: '', message: '' });
  const [msg, setMsg] = useState(null);

  const load = async () => setList((await api.get('/announcements')).data);
  useEffect(() => { load(); }, []);

  const post = async (e) => {
    e.preventDefault();
    try { await api.post('/announcements', form); setForm({ title: '', message: '' }); load(); }
    catch (err) { setMsg(errMsg(err)); }
  };
  const remove = async (id) => { await api.delete(`/announcements/${id}`); load(); };

  return (
    <>
      <Title className="mb-3" icon="megaphone" title="Announcements" subtitle="News and updates from HR" />
      {msg && <div className="alert alert-danger py-2">{msg}</div>}
      {user.role === 'hr' && (
        <form className="card card-body mb-3" onSubmit={post}>
          <input className="form-control mb-2" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <textarea className="form-control mb-2" rows="3" placeholder="Message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required />
          <button className="btn btn-primary align-self-start">Post</button>
        </form>
      )}
      {list.map((a) => (
        <div className="card mb-2" key={a._id}>
          <div className="card-body">
            <div className="d-flex justify-content-between">
              <h6 className="card-title mb-1">{a.title}</h6>
              {user.role === 'hr' && <button className="btn btn-sm btn-outline-danger" onClick={() => remove(a._id)}>Delete</button>}
            </div>
            <p className="mb-1">{a.message}</p>
            <small className="text-muted">Posted by {a.postedBy?.name || 'HR'} on {fmtDate(a.createdAt)}</small>
          </div>
        </div>
      ))}
      {!list.length && <p className="text-muted">No announcements yet.</p>}
    </>
  );
}
