const palette = ['#0E7C66', '#C2410C', '#7C3AED', '#0369A1', '#B45309', '#BE185D', '#4D7C0F'];

export function Avatar({ name = '?', size = 34 }) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  const color = palette[[...name].reduce((a, c) => a + c.charCodeAt(0), 0) % palette.length];
  return (
    <span className="avatar" style={{ width: size, height: size, background: color, fontSize: size * 0.38 }} aria-hidden="true">
      {initials}
    </span>
  );
}

export function Title({ icon, title, subtitle, className = '' }) {
  return (
    <div className={`page-title ${className}`}>
      <span className="page-title-icon"><i className={`bi bi-${icon}`} /></span>
      <div>
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
    </div>
  );
}
