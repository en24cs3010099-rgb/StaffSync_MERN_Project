import { useEffect, useState } from 'react';
import { Title } from '../components/Ui';
import api, { errMsg, fmtDate, statusColor } from '../api';
import { useAuth } from '../AuthContext';

const blank = { type: 'Casual', fromDate: '', toDate: '', reason: '' };
const Badge = ({ s }) => <span className={`badge bg-${statusColor[s]}`}>{s}</span>;

export default function Leaves() {
  const { user } = useAuth();
  const canReview = ['hr', 'manager'].includes(user.role);
  const [tab, setTab] = useState('mine');
  const [mine, setMine] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [form, setForm] = useState(blank);
  const [msg, setMsg] = useState(null);

  const load = async () => {
    setMine((await api.get('/leaves/mine')).data);
    if (canReview) setReviews((await api.get('/leaves')).data);
  };
  useEffect(() => { load(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const apply = async (e) => {
    e.preventDefault();
    try {
      await api.post('/leaves', form);
      setForm(blank); setMsg({ type: 'success', text: 'Leave request submitted' }); load();
    } catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  const review = async (id, status) => {
    const remarks = status === 'rejected' ? window.prompt('Reason for rejection (optional)') || '' : '';
    try { await api.put(`/leaves/${id}/status`, { status, remarks }); load(); }
    catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  const cancel = async (id) => {
    try { await api.delete(`/leaves/${id}`); load(); } catch (err) { setMsg({ type: 'danger', text: errMsg(err) }); }
  };

  return (
    <>
      <Title className="mb-3" icon="calendar2-check" title="Leaves" subtitle="Apply for time off and track approvals" />
      {msg && <div className={`alert alert-${msg.type} py-2`}>{msg.text}</div>}
      {canReview && (
        <ul className="nav nav-tabs mb-3">
          <li className="nav-item"><button className={`nav-link ${tab === 'mine' ? 'active' : ''}`} onClick={() => setTab('mine')}>My Leaves</button></li>
          <li className="nav-item"><button className={`nav-link ${tab === 'review' ? 'active' : ''}`} onClick={() => setTab('review')}>Leave Requests ({reviews.filter((l) => l.status === 'pending').length})</button></li>
        </ul>
      )}

      {tab === 'mine' && (
        <>
          <form className="card card-body mb-3" onSubmit={apply}>
            <div className="row g-2">
              <div className="col-md-2">
                <select className="form-select" value={form.type} onChange={set('type')}>
                  {['Casual', 'Sick', 'Earned', 'Unpaid'].map((t) => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="col-md-2"><input type="date" className="form-control" value={form.fromDate} onChange={set('fromDate')} required /></div>
              <div className="col-md-2"><input type="date" className="form-control" value={form.toDate} onChange={set('toDate')} required /></div>
              <div className="col-md-4"><input className="form-control" placeholder="Reason" value={form.reason} onChange={set('reason')} required /></div>
              <div className="col-md-2"><button className="btn btn-primary w-100">Apply</button></div>
            </div>
          </form>
          <div className="table-responsive">
            <table className="table align-middle">
              <thead className="table-light"><tr><th>Type</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th>Remarks</th><th /></tr></thead>
              <tbody>
                {mine.map((l) => (
                  <tr key={l._id}>
                    <td>{l.type}</td><td>{fmtDate(l.fromDate)}</td><td>{fmtDate(l.toDate)}</td><td>{l.reason}</td>
                    <td><Badge s={l.status} /></td><td>{l.remarks}</td>
                    <td>{l.status === 'pending' && <button className="btn btn-sm btn-outline-danger" onClick={() => cancel(l._id)}>Cancel</button>}</td>
                  </tr>
                ))}
                {!mine.length && <tr><td colSpan="7" className="text-center text-muted">No leave requests yet</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'review' && (
        <div className="table-responsive">
          <table className="table align-middle">
            <thead className="table-light"><tr><th>Employee</th><th>Type</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th /></tr></thead>
            <tbody>
              {reviews.map((l) => (
                <tr key={l._id}>
                  <td>{l.user?.name}<br /><small className="text-muted">{l.user?.department}</small></td>
                  <td>{l.type}</td><td>{fmtDate(l.fromDate)}</td><td>{fmtDate(l.toDate)}</td><td>{l.reason}</td>
                  <td><Badge s={l.status} /></td>
                  <td className="text-nowrap">
                    {l.status === 'pending' && (
                      <>
                        <button className="btn btn-sm btn-success me-1" onClick={() => review(l._id, 'approved')}>Approve</button>
                        <button className="btn btn-sm btn-danger" onClick={() => review(l._id, 'rejected')}>Reject</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
              {!reviews.length && <tr><td colSpan="7" className="text-center text-muted">No requests to review</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
