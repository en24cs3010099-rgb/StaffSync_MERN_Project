import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const errMsg = (e) =>
  e.response?.data?.message ||
  (e.request ? 'Cannot reach the server. Make sure the backend is running (npm run dev).' : e.message);
export const fmtDate = (d) => (d ? new Date(d).toLocaleDateString() : '-');
export const fmtTime = (d) => (d ? new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-');
export const statusColor = { pending: 'warning', approved: 'success', rejected: 'danger' };

export default api;
