import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { Avatar } from './Ui';

const roleLabel = { hr: 'HR', manager: 'Manager', employee: 'Employee' };

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const canManage = ['hr', 'manager'].includes(user.role);
  const cls = ({ isActive }) => 'side-link' + (isActive ? ' active' : '');

  const groups = [
    {
      label: 'My work',
      items: [
        { to: '/', icon: 'grid-1x2-fill', text: 'Dashboard', end: true },
        { to: '/attendance', icon: 'clock-history', text: 'Attendance' },
        { to: '/leaves', icon: 'calendar2-check', text: 'Leaves' },
      ],
    },
    {
      label: 'Company',
      items: [
        { to: '/announcements', icon: 'megaphone', text: 'Announcements' },
        { to: '/training', icon: 'mortarboard', text: 'Training' },
      ],
    },
    ...(canManage
      ? [{ label: 'People', items: [{ to: '/employees', icon: 'people', text: user.role === 'hr' ? 'Employees' : 'My team' }] }]
      : []),
  ];

  return (
    <aside className={`sidebar ${open ? 'open' : ''}`}>
      <NavLink to="/" className="brand" onClick={onClose}>
        <span className="brand-mark"><i className="bi bi-people-fill" /></span>
        StaffSync
      </NavLink>
      <nav aria-label="Main">
        {groups.map((g) => (
          <div key={g.label}>
            <div className="nav-group">{g.label}</div>
            {g.items.map((i) => (
              <NavLink key={i.to} to={i.to} end={i.end} className={cls} onClick={onClose}>
                <i className={`bi bi-${i.icon}`} /> {i.text}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>
      <div className="side-user">
        <Avatar name={user.name} size={38} />
        <NavLink to="/profile" className="side-user-info" onClick={onClose}>
          <span>{user.name}</span>
          <small>{roleLabel[user.role]}</small>
        </NavLink>
        <button className="icon-btn" title="Log out" aria-label="Log out" onClick={() => { logout(); navigate('/login'); }}>
          <i className="bi bi-box-arrow-right" />
        </button>
      </div>
    </aside>
  );
}
