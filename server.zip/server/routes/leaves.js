const router = require('express').Router();
const Leave = require('../models/Leave');
const User = require('../models/User');
const { protect, authorize } = require('../middleware/auth');

router.post('/', protect, async (req, res) => {
  const { type, fromDate, toDate, reason } = req.body;
  if (new Date(toDate) < new Date(fromDate))
    return res.status(400).json({ message: 'End date cannot be before start date' });
  const leave = await Leave.create({ user: req.user._id, type, fromDate, toDate, reason });
  res.status(201).json(leave);
});

router.get('/mine', protect, async (req, res) => {
  res.json(await Leave.find({ user: req.user._id }).sort('-createdAt'));
});

// Leave requests to review (HR: everyone, Manager: own team) - never your own
router.get('/', protect, authorize('hr', 'manager'), async (req, res) => {
  let filter = { user: { $ne: req.user._id } };
  if (req.user.role === 'manager') {
    const teamIds = await User.find({ manager: req.user._id }).distinct('_id');
    filter = { user: { $in: teamIds } };
  }
  res.json(await Leave.find(filter).populate('user', 'name department').sort('-createdAt'));
});

router.put('/:id/status', protect, authorize('hr', 'manager'), async (req, res) => {
  const { status, remarks } = req.body;
  if (!['approved', 'rejected'].includes(status)) return res.status(400).json({ message: 'Invalid status' });
  const leave = await Leave.findById(req.params.id).populate('user', 'manager');
  if (!leave) return res.status(404).json({ message: 'Leave not found' });
  if (req.user.role === 'manager' && String(leave.user.manager) !== String(req.user._id))
    return res.status(403).json({ message: 'You can only review your own team' });
  leave.status = status;
  leave.remarks = remarks || '';
  leave.reviewedBy = req.user._id;
  await leave.save();
  res.json(leave);
});

// Cancel own pending leave
router.delete('/:id', protect, async (req, res) => {
  const leave = await Leave.findOne({ _id: req.params.id, user: req.user._id });
  if (!leave) return res.status(404).json({ message: 'Leave not found' });
  if (leave.status !== 'pending') return res.status(400).json({ message: 'Only pending leaves can be cancelled' });
  await leave.deleteOne();
  res.json({ message: 'Leave cancelled' });
});

module.exports = router;
