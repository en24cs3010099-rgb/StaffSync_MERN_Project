const mongoose = require('mongoose');

module.exports = mongoose.model('Announcement', new mongoose.Schema({
  title: { type: String, required: [true, 'Title is required'] },
  message: { type: String, required: [true, 'Message is required'] },
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true }));
