const router = require('express').Router();
const User = require('../models/User');
const { protect, authorize } = require('../middleware/auth');

// HR: all employees | Manager: own team
router.get('/', protect, authorize('hr', 'manager'), async (req, res) => {
  const filter = req.user.role === 'manager' ? { manager: req.user._id } : {};
  res.json(await User.find(filter).populate('manager', 'name').sort('-createdAt'));
});

router.get('/managers', protect, authorize('hr'), async (req, res) => {
  res.json(await User.find({ role: 'manager' }).select('name'));
});

// Any logged-in user updates own profile
router.put('/me/profile', protect, async (req, res) => {
  const u = await User.findById(req.user._id);
  if (req.body.name) u.name = req.body.name;
  if (req.body.phone !== undefined) u.phone = req.body.phone;
  if (req.body.password) u.password = req.body.password;
  await u.save();
  res.json(await User.findById(u._id));
});

router.post('/', protect, authorize('hr'), async (req, res) => {
  const { name, email, password, role, department, position, phone, manager } = req.body;
  const u = await User.create({ name, email, password, role, department, position, phone, manager: manager || null });
  res.status(201).json(await User.findById(u._id).populate('manager', 'name'));
});

router.put('/:id', protect, authorize('hr'), async (req, res) => {
  const u = await User.findById(req.params.id);
  if (!u) return res.status(404).json({ message: 'Employee not found' });
  ['name', 'email', 'role', 'department', 'position', 'phone'].forEach((k) => {
    if (req.body[k] !== undefined) u[k] = req.body[k];
  });
  if (req.body.manager !== undefined) u.manager = req.body.manager || null;
  if (req.body.password) u.password = req.body.password;
  await u.save();
  res.json(await User.findById(u._id).populate('manager', 'name'));
});

router.delete('/:id', protect, authorize('hr'), async (req, res) => {
  if (String(req.params.id) === String(req.user._id))
    return res.status(400).json({ message: 'You cannot delete your own account' });
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: 'Employee deleted' });
});

module.exports = router;
