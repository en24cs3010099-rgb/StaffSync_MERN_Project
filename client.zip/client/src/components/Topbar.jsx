import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

export default function Topbar({ onMenu }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const initials = user.name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <header className="topbar">
      <button className="menu-btn" onClick={onMenu}><i className="bi bi-list" /></button>
      <div className="text-muted d-none d-sm-block"><i className="bi bi-calendar3 me-2" />{today}</div>
      <div className="ms-auto position-relative">
        <button className="user-btn" onClick={() => setOpen(!open)}>
          <span className="avatar">{initials}</span>
          <span className="d-none d-sm-block lh-sm">
            <span className="d-block fw-semibold">{user.name}</span>
            <small className="text-muted text-capitalize">{user.role}</small>
          </span>
          <i className="bi bi-chevron-down small text-muted" />
        </button>
        {open && (
          <>
            <div className="menu-overlay" onClick={() => setOpen(false)} />
            <div className="user-menu">
              <button onClick={() => { setOpen(false); navigate('/profile'); }}><i className="bi bi-person" /> My Profile</button>
              <button onClick={() => { logout(); navigate('/login'); }}><i className="bi bi-box-arrow-right" /> Logout</button>
            </div>
          </>
        )}
      </div>
    </header>
  );
}
